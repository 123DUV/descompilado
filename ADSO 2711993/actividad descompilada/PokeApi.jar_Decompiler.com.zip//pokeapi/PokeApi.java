package pokeapi;

public class PokeApi {
   public static void main(String[] args) {
      new Pokedex();
   }
}
