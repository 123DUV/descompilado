package pokeapi;

import clases.ConsumoAPI;
import clases.ItemPokemon;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;

public class Pokedex extends JFrame {
   ConsumoAPI consumoAPI;
   ItemPokemon[] items = null;
   JButton[] listaBotones;
   int paginaActual;
   int totalPaginas;
   int offset;
   int limit;
   int[] listaPaginas;
   private JPanel contentCargando;
   private JPanel contentNoInternet;
   private JPanel contentPrincipal;
   private JLabel etqIconoCarga;
   private JLabel etqSinInternet;
   private JLabel etqTitulo;
   private JLabel jLabel1;
   private JLabel jLabel2;
   private JLabel jLabel3;
   private JScrollPane jScrollPane1;
   private JPanel panelBotones;
   private JPanel panelMenu;
   private JPanel panelPaginador;
   private JPanel panelPokemon;

   public Pokedex() {
      int[] temp = new int[]{1, 2, 3, 4, 5, 6, 7};
      this.listaPaginas = temp;
      this.totalPaginas = 65;
      this.limit = 20;
      this.paginaActual = 1;
      this.initComponents();
      this.initAlternComponents();
      this.cargarPaginaPokemons(1);
   }

   public void cargarPaginaPokemons(int pagina) {
      this.paginaActual = pagina;
      this.offset = (this.paginaActual - 1) * 20;
      this.consumoAPI = new ConsumoAPI();
      String textoPagina = this.consumoAPI.consumoGET("https://pokeapi.co/api/v2/pokemon?offset=" + this.offset + "&limit=20");
      if (textoPagina != null) {
         JsonObject objetoJson = JsonParser.parseString(textoPagina).getAsJsonObject();
         JsonArray arregloJson = objetoJson.get("results").getAsJsonArray();
         this.items = new ItemPokemon[arregloJson.size()];
         this.listaBotones = new JButton[arregloJson.size()];
         Gson gson = new Gson();

         for(int i = 0; i < arregloJson.size(); ++i) {
            this.items[i] = (ItemPokemon)gson.fromJson(arregloJson.get(i).getAsJsonObject(), ItemPokemon.class);
         }

         this.contentNoInternet.setVisible(false);
         this.contentCargando.setVisible(false);
         this.contentPrincipal.setVisible(true);
         this.cargarBotonesMenu();
         this.cargarPaginador();
      } else {
         this.contentNoInternet.setVisible(true);
         this.contentCargando.setVisible(false);
         this.contentPrincipal.setVisible(false);
      }

   }

   public void initAlternComponents() {
      this.setTitle("POKEDEX");
      Image icono = this.getToolkit().createImage(ClassLoader.getSystemResource("imagenes/pokeball.png"));
      this.setIconImage(icono);
      Image iconoCarga = this.getToolkit().createImage(ClassLoader.getSystemResource("imagenes/pokeball.gif"));
      this.etqIconoCarga.setHorizontalAlignment(0);
      this.etqIconoCarga.setIcon(new ImageIcon(iconoCarga));
      Image icono_sin_internet = this.getToolkit().createImage(ClassLoader.getSystemResource("imagenes/sin_internet.png"));
      icono_sin_internet = icono_sin_internet.getScaledInstance(300, 200, 4);
      this.etqSinInternet.setIcon(new ImageIcon(icono_sin_internet));
      this.panelPokemon.setAlignmentX(0.5F);
      this.contentNoInternet.setVisible(false);
      this.contentCargando.setVisible(true);
      this.contentPrincipal.setVisible(false);
      this.setLocationRelativeTo((Component)null);
      this.setVisible(true);
   }

   public void cargarPaginador() {
      int i;
      if (this.paginaActual - 4 <= 0) {
         for(i = 0; i < this.listaPaginas.length; ++i) {
            this.listaPaginas[i] = i + 1;
         }
      } else if (this.paginaActual - 4 > 0 && this.paginaActual + 3 < this.totalPaginas) {
         i = this.paginaActual - 3;

         for(int i = 0; i < this.listaPaginas.length; ++i) {
            this.listaPaginas[i] = i++;
         }
      } else if (this.paginaActual + 3 >= this.totalPaginas) {
         for(i = 0; i < this.listaPaginas.length; ++i) {
            this.listaPaginas[i] = this.totalPaginas - (6 - i);
         }
      }

      this.panelPaginador.removeAll();
      this.panelPaginador.add(Box.createHorizontalGlue());
      JButton tempInicio = new JButton("<<");
      tempInicio.setFocusable(false);
      tempInicio.setBackground(Color.white);
      tempInicio.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            Pokedex.this.cargarPaginaPokemons(1);
         }
      });
      this.asignarVistaCursor(tempInicio);
      this.panelPaginador.add(tempInicio);
      JButton tempAtras = new JButton("<");
      tempAtras.setFocusable(false);
      tempAtras.setBackground(Color.white);
      tempAtras.setEnabled(this.paginaActual > 1);
      this.asignarVistaCursor(tempAtras);
      tempAtras.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            if (Pokedex.this.paginaActual > 1) {
               Pokedex.this.cargarPaginaPokemons(Pokedex.this.paginaActual - 1);
            } else {
               System.out.println("NO SE PUEDE RETROCEDER");
            }

         }
      });
      this.panelPaginador.add(tempAtras);

      JButton tempFinal;
      for(int i = 0; i < this.listaPaginas.length; ++i) {
         String var10002 = this.listaPaginas[i] < 10 ? "0" : "";
         tempFinal = new JButton(var10002 + this.listaPaginas[i]);
         tempFinal.setFocusable(false);
         tempFinal.setBackground(this.listaPaginas[i] == this.paginaActual ? Color.blue : Color.white);
         tempFinal.setForeground(this.listaPaginas[i] == this.paginaActual ? Color.white : Color.black);
         final int pag = this.listaPaginas[i];
         tempFinal.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               Pokedex.this.cargarPaginaPokemons(pag);
            }
         });
         this.asignarVistaCursor(tempFinal);
         this.panelPaginador.add(tempFinal);
      }

      JButton tempSiguiente = new JButton(">");
      tempSiguiente.setFocusable(false);
      tempSiguiente.setBackground(Color.white);
      tempSiguiente.setEnabled(this.paginaActual < this.totalPaginas);
      tempSiguiente.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            if (Pokedex.this.paginaActual < Pokedex.this.totalPaginas) {
               Pokedex.this.cargarPaginaPokemons(Pokedex.this.paginaActual + 1);
            } else {
               System.out.println("NO SE PUEDE ADELANTAR");
            }

         }
      });
      this.asignarVistaCursor(tempSiguiente);
      this.panelPaginador.add(tempSiguiente);
      tempFinal = new JButton(">>");
      tempFinal.setFocusable(false);
      tempFinal.setBackground(Color.white);
      tempFinal.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            Pokedex.this.cargarPaginaPokemons(Pokedex.this.totalPaginas);
         }
      });
      this.asignarVistaCursor(tempFinal);
      this.panelPaginador.add(tempFinal);
      this.panelPaginador.add(Box.createHorizontalGlue());
      this.repaint();
      this.revalidate();
   }

   public void cargarBotonesMenu() {
      this.panelBotones.removeAll();

      for(final int i = 0; i < this.items.length; ++i) {
         this.listaBotones[i] = new JButton(this.items[i].getName());
         this.listaBotones[i].setFocusable(false);
         this.listaBotones[i].setBackground(Color.white);
         this.listaBotones[i].setPreferredSize(new Dimension(146, this.listaBotones[i].getPreferredSize().height));
         this.listaBotones[i].setMaximumSize(new Dimension(146, this.listaBotones[i].getPreferredSize().height));
         this.listaBotones[i].setAlignmentX(0.5F);
         this.listaBotones[i].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               Pokedex.this.cambiarPokemon(i);
            }
         });
         this.asignarVistaCursor(this.listaBotones[i]);
         this.panelBotones.add(this.listaBotones[i]);
      }

      this.repaint();
      this.revalidate();
      this.cambiarPokemon(0);
   }

   public void cambiarPokemon(int posicion) {
      ItemPokemon item = this.items[posicion];
      JButton ref = new JButton();

      for(int i = 0; i < this.listaBotones.length; ++i) {
         this.listaBotones[i].setBackground(Color.white);
         this.listaBotones[i].setForeground(ref.getForeground());
      }

      this.listaBotones[posicion].setBackground(Color.blue);
      this.listaBotones[posicion].setForeground(Color.white);
      this.panelPokemon.removeAll();
      infoPokemon temporal = new infoPokemon(item);
      temporal.setSize(this.panelPokemon.getSize());
      temporal.setPreferredSize(this.panelPokemon.getPreferredSize());
      this.panelPokemon.add(temporal);
      this.repaint();
      this.revalidate();
   }

   public void asignarVistaCursor(final JButton btn) {
      btn.addMouseListener(new MouseAdapter() {
         public void mouseEntered(MouseEvent e) {
            btn.setCursor(new Cursor(12));
         }

         public void mouseExited(MouseEvent e) {
            btn.setCursor(new Cursor(0));
         }
      });
   }

   private void initComponents() {
      this.contentPrincipal = new JPanel();
      this.etqTitulo = new JLabel();
      this.panelMenu = new JPanel();
      this.jScrollPane1 = new JScrollPane();
      this.panelBotones = new JPanel();
      this.panelPokemon = new JPanel();
      this.panelPaginador = new JPanel();
      this.contentCargando = new JPanel();
      this.etqIconoCarga = new JLabel();
      this.jLabel1 = new JLabel();
      this.contentNoInternet = new JPanel();
      this.jLabel2 = new JLabel();
      this.jLabel3 = new JLabel();
      this.etqSinInternet = new JLabel();
      this.setDefaultCloseOperation(3);
      this.setResizable(false);
      this.getContentPane().setLayout(new AbsoluteLayout());
      this.contentPrincipal.setBackground(new Color(255, 255, 255));
      this.etqTitulo.setFont(new Font("Segoe UI", 1, 36));
      this.etqTitulo.setForeground(new Color(255, 0, 0));
      this.etqTitulo.setHorizontalAlignment(0);
      this.etqTitulo.setText("POKEDEX");
      this.panelMenu.setBackground(new Color(255, 255, 255));
      this.panelBotones.setBackground(new Color(255, 255, 255));
      this.panelBotones.setLayout(new BoxLayout(this.panelBotones, 3));
      this.jScrollPane1.setViewportView(this.panelBotones);
      GroupLayout panelMenuLayout = new GroupLayout(this.panelMenu);
      this.panelMenu.setLayout(panelMenuLayout);
      panelMenuLayout.setHorizontalGroup(panelMenuLayout.createParallelGroup(Alignment.LEADING).addGroup(panelMenuLayout.createSequentialGroup().addComponent(this.jScrollPane1, -1, 164, 32767).addGap(0, 0, 0)));
      panelMenuLayout.setVerticalGroup(panelMenuLayout.createParallelGroup(Alignment.LEADING).addGroup(panelMenuLayout.createSequentialGroup().addComponent(this.jScrollPane1, -2, 383, -2).addGap(0, 0, 32767)));
      this.panelPokemon.setBackground(new Color(255, 255, 255));
      this.panelPokemon.setLayout(new BoxLayout(this.panelPokemon, 0));
      this.panelPaginador.setLayout(new BoxLayout(this.panelPaginador, 2));
      GroupLayout contentPrincipalLayout = new GroupLayout(this.contentPrincipal);
      this.contentPrincipal.setLayout(contentPrincipalLayout);
      contentPrincipalLayout.setHorizontalGroup(contentPrincipalLayout.createParallelGroup(Alignment.LEADING).addGroup(contentPrincipalLayout.createSequentialGroup().addContainerGap().addGroup(contentPrincipalLayout.createParallelGroup(Alignment.LEADING).addComponent(this.panelPaginador, -1, -1, 32767).addComponent(this.etqTitulo, Alignment.TRAILING, -1, -1, 32767).addGroup(Alignment.TRAILING, contentPrincipalLayout.createSequentialGroup().addComponent(this.panelMenu, -2, -1, -2).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.panelPokemon, -1, 458, 32767))).addContainerGap()));
      contentPrincipalLayout.setVerticalGroup(contentPrincipalLayout.createParallelGroup(Alignment.LEADING).addGroup(contentPrincipalLayout.createSequentialGroup().addComponent(this.etqTitulo, -2, 59, -2).addPreferredGap(ComponentPlacement.RELATED).addGroup(contentPrincipalLayout.createParallelGroup(Alignment.LEADING).addComponent(this.panelMenu, -1, -1, 32767).addComponent(this.panelPokemon, -2, 382, -2)).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.panelPaginador, -2, 42, -2).addGap(14, 14, 14)));
      this.getContentPane().add(this.contentPrincipal, new AbsoluteConstraints(0, 0, 640, 510));
      this.contentCargando.setBackground(new Color(255, 255, 255));
      this.jLabel1.setFont(new Font("Segoe UI", 1, 36));
      this.jLabel1.setHorizontalAlignment(0);
      this.jLabel1.setText("CONSUMIENDO API");
      GroupLayout contentCargandoLayout = new GroupLayout(this.contentCargando);
      this.contentCargando.setLayout(contentCargandoLayout);
      contentCargandoLayout.setHorizontalGroup(contentCargandoLayout.createParallelGroup(Alignment.LEADING).addGroup(contentCargandoLayout.createSequentialGroup().addComponent(this.jLabel1, -1, 634, 32767).addContainerGap()).addComponent(this.etqIconoCarga, Alignment.TRAILING, -1, -1, 32767));
      contentCargandoLayout.setVerticalGroup(contentCargandoLayout.createParallelGroup(Alignment.LEADING).addGroup(contentCargandoLayout.createSequentialGroup().addComponent(this.jLabel1, -2, 78, -2).addPreferredGap(ComponentPlacement.UNRELATED).addComponent(this.etqIconoCarga, -2, 336, -2).addContainerGap(84, 32767)));
      this.getContentPane().add(this.contentCargando, new AbsoluteConstraints(0, 0, 640, 510));
      this.contentNoInternet.setBackground(new Color(255, 255, 255));
      this.jLabel2.setFont(new Font("Segoe UI", 1, 36));
      this.jLabel2.setHorizontalAlignment(0);
      this.jLabel2.setText("INTERNET");
      this.jLabel3.setFont(new Font("Segoe UI", 1, 36));
      this.jLabel3.setHorizontalAlignment(0);
      this.jLabel3.setText("NO NAY CONEXION A");
      this.etqSinInternet.setHorizontalAlignment(0);
      GroupLayout contentNoInternetLayout = new GroupLayout(this.contentNoInternet);
      this.contentNoInternet.setLayout(contentNoInternetLayout);
      contentNoInternetLayout.setHorizontalGroup(contentNoInternetLayout.createParallelGroup(Alignment.LEADING).addGroup(contentNoInternetLayout.createSequentialGroup().addGroup(contentNoInternetLayout.createParallelGroup(Alignment.LEADING).addComponent(this.jLabel3, Alignment.TRAILING, -1, 634, 32767).addComponent(this.jLabel2, -1, -1, 32767).addComponent(this.etqSinInternet, -1, -1, 32767)).addContainerGap()));
      contentNoInternetLayout.setVerticalGroup(contentNoInternetLayout.createParallelGroup(Alignment.LEADING).addGroup(contentNoInternetLayout.createSequentialGroup().addGap(58, 58, 58).addComponent(this.jLabel3).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.jLabel2).addGap(36, 36, 36).addComponent(this.etqSinInternet, -1, 308, 32767).addContainerGap()));
      this.getContentPane().add(this.contentNoInternet, new AbsoluteConstraints(0, 0, 640, 510));
      this.pack();
   }
}
