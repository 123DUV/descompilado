package pokeapi;

import clases.ConsumoAPI;
import clases.ItemPokemon;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;

public class infoPokemon extends JPanel {
   JsonObject dataPokemon;
   ConsumoAPI consumoAPI = new ConsumoAPI();
   ArrayList<String> listaImagenes = new ArrayList();
   int positionImage = 0;
   private JPanel contetnImagenes;
   private JLabel etqImagen;
   private JLabel etqNombre;
   private JLabel etq_atras;
   private JLabel etq_siguiente;
   private JScrollPane jScrollPane1;
   private JTable tablaHabilidades;

   public infoPokemon(ItemPokemon item) {
      String texto = this.consumoAPI.consumoGET(item.getUrl());
      this.dataPokemon = JsonParser.parseString(texto).getAsJsonObject();
      this.initComponents();
      this.initAlternComponents();
   }

   public void initAlternComponents() {
      Image icono_atras = this.getToolkit().createImage(ClassLoader.getSystemResource("imagenes/icono_atras.png"));
      icono_atras = icono_atras.getScaledInstance(50, 50, 4);
      this.etq_atras.setIcon(new ImageIcon(icono_atras));
      Image icono_siguiente = this.getToolkit().createImage(ClassLoader.getSystemResource("imagenes/icono_siguiente.png"));
      icono_siguiente = icono_siguiente.getScaledInstance(50, 50, 4);
      this.etq_siguiente.setIcon(new ImageIcon(icono_siguiente));
      this.etq_atras.addMouseListener(new MouseAdapter() {
         public void mouseEntered(MouseEvent e) {
            infoPokemon.this.etq_atras.setCursor(new Cursor(12));
         }

         public void mouseExited(MouseEvent e) {
            infoPokemon.this.etq_atras.setCursor(new Cursor(0));
         }
      });
      this.etq_siguiente.addMouseListener(new MouseAdapter() {
         public void mouseEntered(MouseEvent e) {
            infoPokemon.this.etq_siguiente.setCursor(new Cursor(12));
         }

         public void mouseExited(MouseEvent e) {
            infoPokemon.this.etq_siguiente.setCursor(new Cursor(0));
         }
      });
      this.etqNombre.setText(this.dataPokemon.get("name").getAsString().toUpperCase());
      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("other").getAsJsonObject().get("home").getAsJsonObject().get("front_default").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("other").getAsJsonObject().get("home").getAsJsonObject().get("front_default").getAsString());
      }

      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("back_default").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("back_default").getAsString());
      }

      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("back_female").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("back_female").getAsString());
      }

      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("back_shiny").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("back_shiny").getAsString());
      }

      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("back_shiny_female").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("back_shiny_female").getAsString());
      }

      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("front_default").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("front_default").getAsString());
      }

      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("front_female").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("front_female").getAsString());
      }

      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("front_shiny").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("front_shiny").getAsString());
      }

      if (!this.dataPokemon.get("sprites").getAsJsonObject().get("front_shiny_female").isJsonNull()) {
         this.listaImagenes.add(this.dataPokemon.get("sprites").getAsJsonObject().get("front_shiny_female").getAsString());
      }

      this.positionImage = 0;
      this.cargarImagePosition();
      this.etq_atras.setEnabled(false);
      DefaultTableModel tableModel = (DefaultTableModel)this.tablaHabilidades.getModel();
      tableModel.setNumRows(0);
      this.tablaHabilidades.getColumnModel().getColumn(0).setPreferredWidth(20);
      this.tablaHabilidades.getColumnModel().getColumn(1).setPreferredWidth(100);
      this.tablaHabilidades.getColumnModel().getColumn(2).setPreferredWidth(200);
      JsonArray habilidades = this.dataPokemon.get("abilities").getAsJsonArray();

      for(int i = 0; i < habilidades.size(); ++i) {
         JsonObject tempHab = habilidades.get(i).getAsJsonObject().get("ability").getAsJsonObject();
         Object[] temporal = new Object[]{i + 1, tempHab.get("name").getAsString(), tempHab.get("url").getAsString()};
         tableModel.addRow(temporal);
      }

   }

   private void initComponents() {
      this.etqNombre = new JLabel();
      this.jScrollPane1 = new JScrollPane();
      this.tablaHabilidades = new JTable();
      this.contetnImagenes = new JPanel();
      this.etqImagen = new JLabel();
      this.etq_siguiente = new JLabel();
      this.etq_atras = new JLabel();
      this.setBackground(new Color(255, 255, 255));
      this.etqNombre.setFont(new Font("Segoe UI", 1, 24));
      this.etqNombre.setHorizontalAlignment(0);
      this.etqNombre.setText("NOMBRE");
      this.tablaHabilidades.setModel(new DefaultTableModel(new Object[0][], new String[]{"N", "Habilidad", "Url"}) {
         Class[] types = new Class[]{String.class, String.class, String.class};
         boolean[] canEdit = new boolean[]{false, false, false};

         public Class getColumnClass(int columnIndex) {
            return this.types[columnIndex];
         }

         public boolean isCellEditable(int rowIndex, int columnIndex) {
            return this.canEdit[columnIndex];
         }
      });
      this.jScrollPane1.setViewportView(this.tablaHabilidades);
      this.contetnImagenes.setBackground(new Color(255, 255, 255));
      this.contetnImagenes.setLayout(new AbsoluteLayout());
      this.etqImagen.setHorizontalAlignment(0);
      this.contetnImagenes.add(this.etqImagen, new AbsoluteConstraints(70, 0, 280, 220));
      this.etq_siguiente.addMouseListener(new MouseAdapter() {
         public void mouseClicked(MouseEvent evt) {
            infoPokemon.this.imagenSiguiente(evt);
         }
      });
      this.contetnImagenes.add(this.etq_siguiente, new AbsoluteConstraints(360, 90, 50, 50));
      this.etq_atras.addMouseListener(new MouseAdapter() {
         public void mouseClicked(MouseEvent evt) {
            infoPokemon.this.imagenAtras(evt);
         }
      });
      this.contetnImagenes.add(this.etq_atras, new AbsoluteConstraints(10, 90, 50, 50));
      GroupLayout layout = new GroupLayout(this);
      this.setLayout(layout);
      layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(Alignment.TRAILING, layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(Alignment.TRAILING).addComponent(this.contetnImagenes, -1, -1, 32767).addComponent(this.etqNombre, Alignment.LEADING, -1, -1, 32767).addComponent(this.jScrollPane1, Alignment.LEADING, -1, 422, 32767)).addContainerGap()));
      layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.etqNombre).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.contetnImagenes, -2, 227, -2).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -1, 120, 32767).addGap(17, 17, 17)));
   }

   private void imagenAtras(MouseEvent evt) {
      if (this.positionImage > 0) {
         --this.positionImage;
         this.cargarImagePosition();
         if (this.positionImage == 0) {
            this.etq_atras.setEnabled(false);
         }
      } else {
         this.etq_atras.setEnabled(false);
      }

      if (this.positionImage == this.listaImagenes.size() - 2) {
         this.etq_siguiente.setEnabled(true);
      }

   }

   private void imagenSiguiente(MouseEvent evt) {
      if (this.positionImage < this.listaImagenes.size() - 1) {
         ++this.positionImage;
         this.cargarImagePosition();
         if (this.positionImage == this.listaImagenes.size() - 1) {
            this.etq_siguiente.setEnabled(false);
         }
      } else {
         this.etq_siguiente.setEnabled(false);
      }

      if (this.positionImage == 1) {
         this.etq_atras.setEnabled(true);
      }

   }

   public void cargarImagePosition() {
      if (this.listaImagenes.size() > 0) {
         String urlStr = (String)this.listaImagenes.get(this.positionImage);

         try {
            URL url = new URL(urlStr);
            Image imagen = Toolkit.getDefaultToolkit().createImage(url);
            imagen = imagen.getScaledInstance(220, 220, 4);
            if (imagen != null) {
               this.etqImagen.setIcon(new ImageIcon(imagen));
            } else {
               System.out.println("No se pudo cargar la imagen desde la URL proporcionada.");
            }
         } catch (Exception var4) {
            System.out.println("Error al cargar la imagen: " + var4.getMessage());
         }
      } else {
         this.etq_siguiente.setEnabled(false);
      }

   }
}
