package clases;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class ConsumoAPI {
   public String consumoGET(String endpoint) {
      try {
         URL url = new URL(endpoint);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("GET");
         int responseCode = connection.getResponseCode();
         if (responseCode != 200) {
            System.out.println("Error al consumir la API. Código de respuesta: " + responseCode);
            connection.disconnect();
            return null;
         } else {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();

            String inputLine;
            while((inputLine = in.readLine()) != null) {
               response.append(inputLine);
            }

            in.close();
            connection.disconnect();
            return response.toString();
         }
      } catch (Exception var8) {
         System.out.println(" -- Catch -- ");
         System.out.println(var8.getMessage());
         return null;
      }
   }

   public String consumoGET(String endpoint, Map<String, String> getData) {
      try {
         StringBuilder urlBuilder = new StringBuilder(endpoint);
         if (!getData.isEmpty()) {
            urlBuilder.append('?');
            Iterator var4 = getData.entrySet().iterator();

            while(var4.hasNext()) {
               Entry<String, String> entry = (Entry)var4.next();
               urlBuilder.append(URLEncoder.encode((String)entry.getKey(), "UTF-8"));
               urlBuilder.append('=');
               urlBuilder.append(URLEncoder.encode((String)entry.getValue(), "UTF-8"));
               urlBuilder.append('&');
            }

            urlBuilder.deleteCharAt(urlBuilder.length() - 1);
         }

         URL url = new URL(urlBuilder.toString());
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("GET");
         int responseCode = connection.getResponseCode();
         if (responseCode != 200) {
            System.out.println("Error al consumir la API. Código de respuesta: " + responseCode);
            connection.disconnect();
            return null;
         } else {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();

            String inputLine;
            while((inputLine = in.readLine()) != null) {
               response.append(inputLine);
            }

            in.close();
            connection.disconnect();
            return response.toString();
         }
      } catch (Exception var10) {
         System.out.println(" -- Catch -- ");
         var10.printStackTrace();
         return null;
      }
   }

   public String consumoPOST(String endpoint) {
      try {
         URL url = new URL(endpoint);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("POST");
         connection.setDoOutput(false);
         int responseCode = connection.getResponseCode();
         if (responseCode != 200) {
            System.out.println("Error al consumir la API. Código de respuesta: " + responseCode);
            connection.disconnect();
            return null;
         } else {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();

            String inputLine;
            while((inputLine = in.readLine()) != null) {
               response.append(inputLine);
            }

            in.close();
            connection.disconnect();
            return response.toString();
         }
      } catch (Exception var8) {
         System.out.println("Error: " + var8.getMessage());
         return null;
      }
   }

   public String consumoPOST(String endpoint, Map<String, String> postData) {
      try {
         URL url = new URL(endpoint);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("POST");
         connection.setDoOutput(true);
         StringBuilder data = new StringBuilder();
         Iterator var6 = postData.entrySet().iterator();

         while(var6.hasNext()) {
            Entry<String, String> entry = (Entry)var6.next();
            if (data.length() != 0) {
               data.append('&');
            }

            data.append((String)entry.getKey());
            data.append('=');
            data.append((String)entry.getValue());
         }

         DataOutputStream wr = new DataOutputStream(connection.getOutputStream());

         try {
            wr.writeBytes(data.toString());
            wr.flush();
         } catch (Throwable var11) {
            try {
               wr.close();
            } catch (Throwable var10) {
               var11.addSuppressed(var10);
            }

            throw var11;
         }

         wr.close();
         int responseCode = connection.getResponseCode();
         if (responseCode != 200) {
            System.out.println("Error al consumir la API. Código de respuesta: " + responseCode);
            connection.disconnect();
            return null;
         } else {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();

            String inputLine;
            while((inputLine = in.readLine()) != null) {
               response.append(inputLine);
            }

            in.close();
            connection.disconnect();
            return response.toString();
         }
      } catch (Exception var12) {
         System.out.println("Error: " + var12.getMessage());
         return null;
      }
   }
}
